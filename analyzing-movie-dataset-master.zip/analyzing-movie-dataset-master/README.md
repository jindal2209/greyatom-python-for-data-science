### Project Overview

 Grey atom MOVIE DATA SET PROJECT


### Learnings from the project

 CSV
data handling 



